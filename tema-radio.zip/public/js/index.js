var lupa = document.getElementById("lupa");
var caixaDePesquisa = document.getElementById("caixa-de-pesquisa");

lupa.addEventListener("click", function () {
  caixaDePesquisa.classList.toggle("invisivel");
});

function mostrarDiv(id, btnId) {
  const divs = ['segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado', 'domingo'];
  const btns = ['bt-segunda', 'bt-terca', 'bt-quarta', 'bt-quinta', 'bt-sexta', 'bt-sabado', 'bt-domingo'];

  for (var i = 0; i < divs.length; i++) {
    document.getElementById(divs[i]).style.display = 'none';
    document.getElementById(btns[i]).classList.remove('focus');
  }
  document.getElementById(id).style.display = 'flex';
  document.getElementById(btnId).classList.add('focus');
}

var diaDaSemana = new Date().getDay();

if (diaDaSemana == 0) mostrarDiv('domingo', 'bt-domingo');
else if (diaDaSemana == 1) mostrarDiv('segunda', 'bt-segunda');
else if (diaDaSemana == 2) mostrarDiv('terca', 'bt-terca');
else if (diaDaSemana == 3) mostrarDiv('quarta', 'bt-quarta');
else if (diaDaSemana == 4) mostrarDiv('quinta', 'bt-quinta');
else if (diaDaSemana == 5) mostrarDiv('sexta', 'bt-sexta');
else mostrarDiv('sabado', 'bt-sabado');